package com.example.pleut;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private Button tune;
    private TextView one;
    private TextView two;
    private TextView tree;
    private EditText second;
    private int solde = 0;
    private View black;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable( new ColorDrawable(getResources().getColor(R.color.teal_700)));

         tune = findViewById(R.id.button2);
         one = findViewById(R.id.textView);
         two = findViewById(R.id.textView2);
         tree = findViewById(R.id.textView3);
         black = findViewById(R.id.back);
         second = findViewById(R.id.editTextTextPersonName);



         tune.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {


                 solde += 1000;
                 two.setText("solde " + solde + "$");
                 if (solde >=5000)
                 {
                     black.setBackgroundResource(R.color.yellow);
                     two.setTextColor((getResources().getColor(R.color.black)));
                     tree.setTextColor((getResources().getColor(R.color.black)));
                     Toast.makeText(MainActivity.this, second.getText().toString()  + " Vous êtes riche à présent  " , Toast.LENGTH_SHORT).show();

                 }

                 if (solde >10000)
                 {
                     black.setBackgroundResource(R.color.purple_700);
                     Toast.makeText(MainActivity.this, second.getText().toString()  + " Vous venez d'atteindre le planfond des millonnaire " , Toast.LENGTH_SHORT).show();
                     two.setTextColor((getResources().getColor(R.color.white)));
                     tree.setTextColor((getResources().getColor(R.color.white)));
                 }



             }




             });



    }
}